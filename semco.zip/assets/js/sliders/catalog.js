new Splide( '.catalog-slider', {
  perMove: 1,
  type   : 'loop',
  perPage: 1,
  autoplay: true,
  flickMaxPages: 1,
  gap: 20,
} ).mount();
