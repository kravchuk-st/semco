new Splide( '.discount_slider', {
  perMove: 1,
  type   : 'loop',
  perPage: 3,
  autoplay: true,
  gap: 40,
  flickMaxPages: 1,
} ).mount();
