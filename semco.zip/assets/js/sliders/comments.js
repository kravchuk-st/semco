new Splide( '.comments_slider', {
  perMove: 1,
  type   : 'loop',
  perPage: 4,
  autoplay: true,
  gap: 40,
  flickMaxPages: 1,
} ).mount();
